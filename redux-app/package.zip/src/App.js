import React, { Component } from "react";
import Container from "react-bootstrap/Container";
import Col from "react-bootstrap/Col";
import Row from "react-bootstrap/Row";
import { Route } from 'react-router-dom';
import Header from "./components/Header";
import Navigation from './components/Navigation';

import Button from './components/button/button';


import AddToDo from "./containers/AddToDo";
import ToDoListContainer from "./containers/ToDoListContainer";

class App extends Component {
  render() {
    return (
      <div>
       <Container>
        <Row className="row">
          <Col xs={12}>
            <Button label="Click me please"> </Button> 
            <Header description="To do list App with React, Redux and Sega middleware" />
            <Navigation />            
            <Route exact path="/" component={ToDoListContainer} />
            <Route exact path="/new-item" component={AddToDo} />
          </Col>
        </Row>
      </Container> 
      </div>
    );
  }
}

export default App;
